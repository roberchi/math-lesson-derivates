// See docs/ADAPTIVE.md
